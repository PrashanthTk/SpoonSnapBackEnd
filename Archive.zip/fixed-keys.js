// keys.js
// Contains keys to run this demo
// The keys should be kept secret and separate from the code
// Enter your keys below to take the first in running this step 
// VROOOOM VROOM

// Returns an object with the required credentials
function getKeys () {
	return {
		CLARIFAI_CLIENT_ID: "jx09e8kewIW2oGl59zliP7D-PRvNtrqpsiMf-bnY",
		CLARIFAI_CLIENT_SECRET: "K5e99cs2MqlK6bj6ZKXgI9YphzwoLlbHETVcUoBo"
	}
}